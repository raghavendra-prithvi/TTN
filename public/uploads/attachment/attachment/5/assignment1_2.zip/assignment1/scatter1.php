<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>D3 Test</title>
        <script type="text/javascript" src="d3/d3.v3.js"></script>
    </head>
    <body>
    <style>

	</style>
    
        <script type="text/javascript">
        
        
        	var w = 900;
		var h = 400;
		var padding = 40;
       
/*
Notes:
	1) First made scatterplot with (x,y) = (exper, lnw). Noticed higher density
	of data points with a correlation of low experience to low wage. But it's a mess
	with no clear results. So, I tried something else.
	2) Made a scatterplot with (x,y) = (hgc, lnw) to see the effect of education on wages
	earned, but hgc just grouped the data points into 7 groups. Not too helpful, but gave me 
	an idea to use color to represent the hgc.
	3) Now back to (1: (x,y) = (exper,lnw)) but I created a color scale to assign colors to the
	seven different hgc levels. It is still a mess. I am going to work with subsets now... starting
	to get some ideas for possibly interesting data. For instance, maybe I can specifcy the unemployment
	rate in the area and start seeing data within those groups. 
        
  */
		
function create_graph(dataset){
        //Width and height

		var xScale = d3.scale.linear()
                     .domain([0, d3.max(dataset, function(d) { return +d["exper"]; })])
                     .range([padding, w - padding]);
        var yScale = d3.scale.linear()
                     .domain([0, d3.max(dataset, function(d) { return +d["lnw"]; })])
                     .range([h - padding, padding]);
                     
        var rScale = d3.scale.linear()
                     .domain([0, d3.max(dataset, function(d) { return +d["lnw"]; })])
                     .range([2, 5]);
              
        var fillsScale = d3.scale.linear()
        					.domain([0, 12]).rangeRound([0,6]);
          
                  
        
              
		var svg = d3.select("body")
        	    .append("svg")
            	.attr("width", w)
            	.attr("height", h);
		
		
  		
  var fills = ['red', 'green', 'blue', 'cyan', 'black', 'yellow', 'purple' ];
				
		svg.selectAll("circle")
   			.data(dataset)
   			.enter()
   			.append("circle")
   		/*	.filter(function(d){
   				return +d["hispanic"] == 0 &&
   						+d["black"] == 0;})
   		*/	.attr("cx", function(d) {
    			return xScale(+d["exper"]);
				})
   			.attr("cy", function(d) {
        		return yScale(+d["lnw"]);
  			 })
   			.attr("r", function(d) {
   				 return rScale(+d["lnw"]); })
   			.attr("fill", function(d) {
   				 return fills[fillsScale(+d["hgc"])]; });
		
				
	  // Axes
    var xAxis = d3.svg.axis()
                    .scale(xScale)
                    .orient("bottom")
                    .ticks(5);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(0," + (h - padding) + ")")
        .call(xAxis);

    var yAxis = d3.svg.axis()
                      .scale(yScale)
                      .orient("left")
                      .ticks(5);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(" + padding + ",0)")
        .call(yAxis); 
       }

d3.csv("wages.csv", create_graph);

       </script>

        <div class="bar"></div>

    </body>
</html>