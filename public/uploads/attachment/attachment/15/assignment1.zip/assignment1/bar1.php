<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>D3 Test</title>
        <script type="text/javascript" src="d3/d3.v3.js"></script>
    </head>
    <body>
    <style>

	</style>
    
        <script type="text/javascript">
        
        
        	var w = 900;
		var h = 400;
		var padding = 40;
       
/*
Notes:
	1)	Attempting bar graph. First: made with (x,y) => (exper, lnw) but nothing
		is showing. The rectangular objects are being creating. Thinking it's just
		too much data. going to try and filter/ group.
	2) Setting using dataset[2] to access "exper" column.
	3) Learning how to choose subsets. Just want a simple selection choosing 
		only showing someone's id's info.
	4) Not working out, will need to figure out what's going wrong here.
        
  */
		
function create_graph(dataset){
        //Width and height
		var padding = 20;

		var xScale = d3.scale.linear()
                     .domain([0, d3.max(dataset, function(d) { return +d["exper"]; })])
                     .range([padding, w - padding]);
        var yScale = d3.scale.linear()
                     .domain([0, d3.max(dataset, function(d) { return +d["lnw"]; })])
                     .range([h - padding, padding]);


        var barPadding = 1; 
                  
        
              
		var svg = d3.select("body")
        	    .append("svg")
            	.attr("width", w)
            	.attr("height", h);
		
		svg.selectAll("rect")
   			.data(dataset)
   			.enter()
  			.append("rect")
  			.filter(function(d) { 
  				return +d["id"] == 36; 
  				})
  			.attr("x", function(d, i) {
    			return i * 100;
				})
   			.attr("y", h - +d["lnw"])
			.attr("width", 20)
   			.attr("height", function(d) {
   				 return +d["lnw"];
				});
   			
   			

		
				
	  // Axes
    var xAxis = d3.svg.axis()
                    .scale(xScale)
                    .orient("bottom")
                    .ticks(40);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(0," + (h - padding) + ")")
        .call(xAxis);

    var yAxis = d3.svg.axis()
                      .scale(yScale)
                      .orient("left")
                      .ticks(40);

    svg.append("g")
        .attr("class", "axis")
        .attr("transform", "translate(" + padding + ",0)")
        .call(yAxis); 
       }

d3.csv("wages.csv", create_graph);

       </script>

        <div class="bar"></div>

    </body>
</html>