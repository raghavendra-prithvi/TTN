# Program to create PWM from reading Binding Site Probability
# and background frequency

import csv
import math
import detectBindingSite
import re
import pdb


def createPWM(input):
    print input

def log(float):
    if float == 0:
        float = 0.00000007
        return math.log(float)
    else:
        return math.log(float)
    
def main():

    pwmMatrix = []
    sumCol = {}
    threshold = 6.5
    with open('pwm.csv', 'U') as doc:
        file = csv.reader(doc, delimiter=' ')
        for line in file:
    #Get the binding probabilities
          
            if 'A' in line:
                aBind = line
            if 'C' in line:
                cBind = line
            if 'G' in line:
                gBind = line
            if 'T' in line:
                tBind = line
        

     #Get the nt frequencies
            if 'af' in line:
                af = float(line[1])
            if 'cf' in line:
                cf = float(line[1])
            if 'gf' in line:
                gf = float(line[1])
            if 'tf' in line:
                tf = float(line[1])

        
        #Gather sums of each column
        for i in range(len(aBind)):
            if i != 0:
                sumCol[i] = float(aBind[i])
        for i in range(len(cBind)):
            if i != 0:
                sumCol[i] += float(cBind[i])
        for i in range(len(gBind)):
            if i != 0:
                sumCol[i] += float(gBind[i])
        for i in range(len(tBind)):
            if i != 0:
                sumCol[i] += float(tBind[i])

        # Get log Odds Ratio and create matrix
        freqa = []
        freqc = []
        freqg = []
        freqt = []
        for i in range(len(aBind)):
            if i !=0:
                freqa.append(log(float(aBind[i])/float(sumCol[i])/af))
        pwmMatrix.append(freqa)
        for i in range(len(cBind)):
            if i !=0:
                freqc.append(log(float(cBind[i])/float(sumCol[i])/cf))
        pwmMatrix.append(freqc)
        for i in range(len(gBind)):
            if i !=0:
                freqg.append(log(float(gBind[i])/float(sumCol[i])/gf))
        pwmMatrix.append(freqg)
        for i in range(len(tBind)):
            if i !=0:
                freqt.append(log(float(tBind[i])/float(sumCol[i])/tf))
        pwmMatrix.append(freqt)

        # Print matrix
        print 'Position Weight Matrix'
        print
        for i in pwmMatrix:
            for j in i:
                print j,
            print
                

#Process Chimp Genome with pwmMatrix to find likely binding sites
    print 'Finding likely sites with score greater than threshold of',
    print threshold
    for line in open("upstream1000.fa"):
        li=line.strip()
        if not li.startswith(">"):
            detectBindingSite.detect(pwmMatrix, line.rstrip(), threshold) 

    sites = detectBindingSite.getSites()
    histogramVals = []
    for key, value in sites.iteritems() :
        print key, ' has a score of ', value
        histogramVals.append(value)
    #create array for use in RStudio or Excel for histogram
    print 'For use in RStudio to create histogram: '
    print histogramVals
        

   
main()



