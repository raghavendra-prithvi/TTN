import pdb

goodRegion = {}
def getScore(window, pwm):
    score = 0
    for i in range(len(window)):
        if window[i] == 'a':
           score += pwm[0][i] 
        if window[i] == 'c':
           score += pwm[1][i]         
        if window[i] == 'g':
           score += pwm[2][i] 
        if window[i] == 't':
            score += pwm[3][i]
    return score


def detect(pwm, promoter, threshold):
    
        
    lenWindow = len(pwm[0])
    global goodRegion
    promoterList = list(promoter)
    for i in range(len(promoterList) - lenWindow + 1):
        site = ''.join(promoterList[i:lenWindow + i])
        score = getScore(site, pwm)
        if score >= threshold:
            if site not in goodRegion.keys():
                goodRegion[site] = score
    

def getSites():
    global goodRegion
    return goodRegion



















